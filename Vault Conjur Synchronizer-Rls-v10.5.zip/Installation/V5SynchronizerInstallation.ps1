﻿#-----------------------------------------
# This script installs the Vault-Conjur Synchronizer
#------------------------------------------

#Requires -Version 4.0

# ----------------- Global Variables Start -----------------
param([switch] $silent)

$global:ScriptDir = $null
$global:LogFilePath = $null
$global:LogFolderPath = $null

$global:Config=@{}
$global:InstallationTargetPath="InstallationTargetPath"
$global:ConjurServerDNS="ConjurServerDNS"
$global:VaultName="VaultName"
$global:VaultAddress="VaultAddress"
$global:VaultPort="VaultPort"
$global:SynchronizerVaultUsername="SynchronizerVaultUsername"
$global:ConjurCredentialsFilePath="ConjurCredentialsFilePath"
$global:ConjurAccountKey="ConjurAccount"
$global:ConjurAuthenApiKey="ConjurAuthnApi"
$global:ConjurAuthenUserKey="ConjurAuthnUser"
$global:ConjurTokenKey="ConjurTokenKey"

# Sets the value in the config
function SetValueInConfig($key, $value)
{
    if ($silent -and $global:Config.ContainsKey($key))
    {
        return
    }
    
    $global:Config.Add($key, $value)
}

# Replace the value in the config
function ReplaceValueInConfig($key, $value)
{
    $global:Config[$key] = $value
}

# Returns the value from the config
function GetValueFromConfig($key)
{
    return $global:Config.Get_Item($key)
}

# ----------------- Global Variables End -----------------

# ----------------- Create Conjur Host and Policy -----------------
# Creates a policy file with a host for the Synchronizer and vault policy loads it to Conjur
function CreateConjurHostAndPolicy($conjurHostId, $conjurHostCredFileOutputPath, $vaultName)
{
    WriteOutput -Message "Creating Synchronizer Conjur host and vault policy" -newLine

    # Check if host already exists in Conjur
    $baseUri = (GetValueFromConfig -key $global:ConjurServerDNS)
    $conjurAccount = (GetValueFromConfig -key $global:ConjurAccountKey)
    $conjurToken = (GetValueFromConfig -key $global:ConjurTokenKey)
    
    $conjurHostIdEncoded = [System.Web.HttpUtility]::UrlEncode($conjurHostId)
    $conjurAccountEncoded = [System.Web.HttpUtility]::UrlEncode($conjurAccount)
    $isHostExists = $false
    
    $hostUri = "$baseUri/resources/$conjurAccountEncoded/host/$conjurHostIdEncoded"
    try
    {
        $searchHostResponse = Invoke-RestMethod -Uri $hostUri -Headers @{"Authorization"="Token token=`"$conjurToken`""}
        Write-Warning -Message "Synchronizer Conjur host $conjurHostId already exists" | Tee-Object -Append $global:LogFilePath
        $isHostExists = $true
    }
    catch
    {
        $statusCode = $_.Exception.Response.StatusCode.Value__
        
        if ($statusCode -ne 404)
        { 
            throw "Couldn't create Synchronizer Conjur host $conjurHostId, failed in existance search. [$searchHostResponse, $_.ErrorDetails]"
        }
    }
        
    # Create host and policy
    $policyFileContent = @" 
- !group
  id: $vaultName-admins
- !host
  id: $conjurHostId
 
- !grant
  role: !group $vaultName-admins
  members:
  - !host $conjurHostId
   
- !policy
  id: $vaultName
  owner: !group $vaultName-admins
"@ 
    
    $loadPolicyUri = "$baseUri/policies/$conjurAccountEncoded/policy/root"	
    try
    {
        $createHostResponse = Invoke-RestMethod -Method Post -Uri $loadPolicyUri -Headers @{"Authorization"="Token token=`"$conjurToken`""} -Body $policyFileContent
    }
    catch
    {
        $statusCode = $_.Exception.Response.StatusCode.Value__
        throw "Couldn't create Synchronizer Conjur host $conjurHostId, failed to load policy. [$createHostResponse, $statusCode $_.ErrorDetails]"
    }

    if (-not $isHostExists)
    {
        try
        {
            $hostParamKey = "$conjurAccount`:host`:$conjurHostId"
            $objectApiKey = $createHostResponse.created_roles.$hostParamKey.api_key

            if (-not $objectApiKey)
            {
                throw
            }
        }
        catch
        {
            throw "Failed to parse response from load policy which creates host and synchronizer policy."
        }
        
        $psHostname = "host/$conjurHostId"
        $psApiKey = ConvertTo-SecureString -String $objectApiKey -AsPlainText -Force

        CreatePSCredentials -username $psHostname -password $psApiKey -outputPath $conjurHostCredFileOutputPath

        WriteOutput -Message "Wrote Synchronizer Conjur host credentials to $conjurHostCredFileOutputPath"
    }
}

# ----------------- Init Conjur -----------------
# Inits Conjur by sending authentication REST requests to the propmted hostname 
function InitConjur()
{
    WriteOutput -Message "Starting Conjur authentication process" -newLine

    if ($silent)
    {
        $credentials = Import-Clixml -Path (GetValueFromConfig -key $global:ConjurCredentialsFilePath)
        $conjurUser = $credentials.UserName

        # The password will be disposed in ConvertSecurePasswordToPlainText
        $conjurApiKey = ConvertSecurePasswordToPlainText -securePassword $credentials.Password
        $conjurHost = (GetValueFromConfig -key $global:ConjurServerDNS)
        $conjurAccount = (GetValueFromConfig -key $global:ConjurAccountKey)
    }
    else
    {
        $conjurUser = ReadHostWithDefaultValue -Message "Specify the Conjur username" -defaultValue "admin"
        $conjurApiKey = GetPassword -userPromptMsg "Specify the Conjur API Key or password (will not be echoed)"
        $conjurHost = ReadHost "Specify Conjur server hostname (and optional port in the format of hostname[:port])"
        $conjurAccount = ReadHost "Specify Conjur account name"
        
        SetValueInConfig -key $global:ConjurAccountKey -value $conjurAccount
    }

    ReplaceValueInConfig -key $global:ConjurServerDNS -value "https://$conjurHost"
    $conjurHost = (GetValueFromConfig -key $global:ConjurServerDNS)

    SetValueInConfig -key $global:ConjurAuthenUserKey -value $conjurUser
    SetValueInConfig -key $global:ConjurAuthenApiKey -value $conjurApiKey
    
    $encodedConjurAccount = [System.Web.HttpUtility]::UrlEncode($conjurAccount)
    
    WriteOutput -Message "Retrieving certificate" -newLine	
	$InstallationTargetPath = (GetValueFromConfig -key $global:InstallationTargetPath)
	$ConjurCertFilePath = "$InstallationTargetPath\conjur.pem"
    RemoveFileIfExist -FileName $ConjurCertFilePath
    Save-Certificate -serverUri "$conjurHost/info" -certPath $ConjurCertFilePath
    
    WriteOutput -Message "Sending login request to Conjur" -newLine
    $loginResponse = ConjurLogin -baseUri $conjurHost -conjurAccount $encodedConjurAccount
    
    WriteOutput -Message "Sending authentication request to Conjur" -newLine
    $authenticationResponse = ConjurAuthenticate -baseUri $conjurHost -conjurAccount $encodedConjurAccount -conjurApiKey $loginResponse
    $conjurToken = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("$authenticationResponse"))
    SetValueInConfig -key $global:ConjurTokenKey -value $conjurToken
}

# ----------------- Conjur login REST -----------------
# Invoke REST login API to Conjur host
# Argument conjurAccount needs to be encoded
function ConjurLogin($baseUri, $conjurAccount)
{
    $conjurUser = (GetValueFromConfig -key $global:ConjurAuthenUserKey)
    $conjurSecret = (GetValueFromConfig -key $global:ConjurAuthenApiKey)

    $basicCreds = Get-BasicAuthCreds -user $conjurUser -secret $conjurSecret
    
    $conjurLoginUri = "$baseUri/authn/$conjurAccount/login"
    try
    {
        $loginResponse = Invoke-RestMethod -Uri $conjurLoginUri -Headers @{"Authorization"="Basic $basicCreds"}
    }
    catch
    {
        throw "Could not login to Conjur. [$_.ErrorDetails]"
    }
    
    return $loginResponse
}

# ----------------- Conjur authenticate REST -----------------
# Invoke REST authenticate API to Conjur host
# Argument conjurAccount needs to be encoded
function ConjurAuthenticate($baseUri, $conjurAccount, $conjurApiKey)
{
    $encodedconjurUser = [System.Web.HttpUtility]::UrlEncode((GetValueFromConfig -key $global:ConjurAuthenUserKey))
    
    $conjurAuthenticateUri = "$baseUri/authn/$conjurAccount/$encodedconjurUser/authenticate"
    try
    {
        $authenticateResponse = Invoke-RestMethod -Method Post -Uri $conjurAuthenticateUri -Body $conjurApiKey
    }
    catch
    {
        throw "Could not authenticate to Conjur. [$_.ErrorDetails]"
    }
    
    return ($authenticateResponse | ConvertTo-Json -Compress)
}

# ----------------- Create CredFile -----------------
function CreateCredFile($credFilePath, $createcredfilePath, $runningExePath) 
{
    WriteOutput -Message "Creating a credentials file for the Synchronizer Vault user" -newLine
    $SynchronizerVaultUsername = ReadHostWithDefaultValue -Message "Specify the Synchronizer Vault User's username" -defaultValue "Sync_$env:computername"
    $SynchronizerVaultUserPassword = GetPassword -userPromptMsg "Specify the Synchronizer Vault User's password (will not be echoed)"

    & "$createcredfilePath\CreateCredFile.exe" @("`"$credFilePath`"", "Password", "/Username", $SynchronizerVaultUsername, "/Password", $SynchronizerVaultUserPassword, "/ExePath", $runningExePath, "/Hostname")

    SetValueInConfig -key $global:SynchronizerVaultUsername -value $SynchronizerVaultUsername
}

# ----------------- Update Vault.ini -----------------
# notice address should contain no quotes to support DR
function UpdateVaultIni($filePath, $vaultName, $VaultAddress, $vaultPort)
{
    $fileContent = (Get-Content -path $filePath)

    $fileContent = $fileContent -replace "VAULT\s?=\s?`"?[\s\S]*`"?", "VAULT=`"$vaultName`""
    $fileContent = $fileContent -replace "ADDRESS\s?=\s?`"?[\s\S]*`"?", "ADDRESS=$VaultAddress"
    $fileContent = $fileContent -replace "PORT\s?=\s?`"?[\s\S]*`"?", "PORT=`"$vaultPort`""

    $fileContent | Set-Content $filePath
}

# ----------------- Update Config file -----------------
function UpdateConfigFile($filePath, $Items)
{
    WriteOutput -Message "Updating file $filePath" -newLine
    
    $parsedValues = @{}
    
    $Items = $Items -split ", "
    $Items | foreach {
        $item = $_.split("=")
        $parsedValues.Add($item[0], $item[1])
    }
        
    $xml = [xml](Get-Content $filePath)
    foreach ($elem in $xml.configuration.appSettings.ChildNodes)
    { 
        if ($elem.key)
        {
            if ($parsedValues.ContainsKey($elem.key))
            {
                WriteOutput -Message "Updating the value of $($elem.key) to $($parsedValues[$elem.key])"
                $elem.value = $parsedValues[$elem.key]
            }
        }
    }
    
    $xml.Save($filePath)
}

function UpdateTargetInstallationFolderPermissions()
{
    $InstallationTargetPath = (GetValueFromConfig -key $global:InstallationTargetPath)
    WriteOutput -Message "Setting access permission recursively to folder $InstallationTargetPath for Administrators Group" -newLine
    
    ### set Synchronizer Installation folder ACL ###

    # retrieve ACL (Access Control List) of Installation target folder 
    $Acl = Get-Acl $InstallationTargetPath
    # protect the access rules associated with this ObjectSecurity object from inheritance (=True) & Don't preserve inherited access rules (=False)
    $Acl.SetAccessRuleProtection($True , $False)     
    # Grant “Full Control” permissions to Administrators 
    $Ar = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators","FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
    $Acl.SetAccessRule($Ar)
    # Grant "Read" permissions to Users
    $Ar = New-Object System.Security.AccessControl.FileSystemAccessRule("Users","Read", "None", "None","Allow")
    $Acl.SetAccessRule($Ar)
    Set-Acl $InstallationTargetPath $Acl
}

################################################################################################
#  Utils
################################################################################################

# ----------------- Get Basic authentication credentials -----------------
# Convert given user and secret to compile with basic authorization format
function Get-BasicAuthCreds($user, $secret)
{
    $authString = "{0}:{1}" -f $user,$secret
    $authBytes = [System.Text.Encoding]::Ascii.GetBytes($authString)
    return [Convert]::ToBase64String($authBytes)
}

# ----------------- Save Certificate -----------------
# Retrieve certificate from remote server and load it to root cert store
function Save-Certificate($serverUri, $certPath)
{
    $builder = New-Object System.Text.StringBuilder
    $request = [System.Net.WebRequest]::CreateHttp($serverUri)
    $request.ServerCertificateValidationCallback = 
    {
        param(
        [System.Object]$sender,
        [System.Security.Cryptography.X509Certificates.X509Certificate]$certificate,
        [System.Security.Cryptography.X509Certificates.X509Chain]$chain,
        [System.Net.Security.SslPolicyErrors]$sslPolicyErrors)

        $cert2 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $certificate

        if ($chain.Build($cert2))
        {
            return $true;
        }

        $issuer = $chain.ChainElements[$chain.ChainElements.Count - 1].Certificate

        $builder.AppendLine("-----BEGIN CERTIFICATE-----")
        $builder.AppendLine([System.Convert]::ToBase64String($issuer.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert), [System.Base64FormattingOptions]::InsertLineBreaks))
        $builder.AppendLine("-----END CERTIFICATE-----")
    
        return $true
    }

    $response = $request.GetResponse()

    if ($builder.Length -gt 0)
    {
        [System.IO.File]::WriteAllText($certPath, $builder.ToString())
        $responseCertLoad = Import-Certificate -CertStoreLocation "Cert:\LocalMachine\Root" -FilePath $certPath
        WriteOutput -Message "Server certificate was loaded into LocalMachie\Root store, $responseCertLoad" -newLine
        [System.IO.File]::Delete($certPath)
    }

}

function ConvertSecurePasswordToPlainText($securePassword) 
{
    $BSTR = [System.IntPtr]::Zero
    try 
    {
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
        $plainTextPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
        return $plainTextPassword
    } 
    finally 
    {
        $securePassword.Dispose()
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
    }
}

# ----------------- Get Password -----------------
# Receive the password from the user in a secured manner and tranform it to plain text for login
function GetPassword($userPromptMsg) 
{
    $securePassword = ReadHost $userPromptMsg -AsSecureString

    # The password will be disposed in ConvertSecurePasswordToPlainText
    return ConvertSecurePasswordToPlainText -securePassword $securePassword
}

# ----------------- Unzip -----------------
# Unzip a specifed zip file to a specified location, if not exists in the output path
function Unzip($zipfile, $outpath)
{
    WriteOutput -Message "Unzipping $zipfile to $outpath"

    if(-not (Test-Path $outpath ))
    {
        [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $outpath)
    }
    else 
    {
        WriteOutput -Message "Directory $outpath already exists"
    }
}

# ----------------- Remove File If Exist -----------------
# Removes a file from a specified location, if it exists
function RemoveFileIfExist($FileName)
{
    if (Test-Path $FileName) 
    {
        WriteOutput -Message "Removing file $FileName" 
        Remove-Item $FileName
    }
}

# ----------------- Write Output -----------------
# Wrapper for the PowerShell Write-Output
function WriteOutput($message, [switch]$newLine)
{
    if ($newLine) 
    {
        $message = "`r`n$message"
    }

    Write-Output $message | Tee-Object -Append $global:LogFilePath
}

# ----------------- Read Host -----------------
# Wrapper for the PowerShell Read-Host 
function ReadHost($message, [switch] $AsSecureString)
{
    if ($silent)
    {
        return
    }

    $message = "`r`n$message"

    # Write to log file
    $message | Out-File $global:LogFilePath -Append
    
    if ($AsSecureString) 
    {
        return (Read-Host "$message" -AsSecureString)
    }
    else
    {
        $input = Read-Host "$message"
        
        # Write to log file
        $input | Out-File $global:LogFilePath -Append
        
        return ($input)
    }
}

# Reads input from host with default value
function ReadHostWithDefaultValue($message, $defaultValue)
{
    $ret = ReadHost -Message "$message [$defaultValue]"
    if ($ret -eq '' -and $defaultValue -ne '') 
    {
        $ret = $defaultValue
    }

    # Write to log file
    $ret | Out-File $global:LogFilePath -Append
    return $ret
}

# ----------------- Read config file -----------------
function VerifyMandatoryParam($key)
{
    $value = GetValueFromConfig -key $key
    if ([string]::IsNullOrEmpty($value) -or [string]::IsNullOrWhiteSpace($value))
    {
        throw "Missing mandatory param [$key]"
    }
}

# ----------------- Read Silent Installation Config File -----------------
function ReadSilentInstallationConfigFile($path)
{
    $SingleQuoteRegex = '^"(.*)"$'
    $DoubleQuoteRegex = "^'(.*)'$"

    $fileContent = Get-Content $path
    foreach ($line in $fileContent) 
    {
        $values = [regex]::split($line,'=')
        if (($values[0].CompareTo("") -ne 0) -and (-not $values[0].StartsWith("[")) -and (-not $values[0].StartsWith("#"))) 
        { 
            SetValueInConfig -key $values[0] -value ($values[1] -replace $DoubleQuoteRegex,'$1' -replace $SingleQuoteRegex,'$1') 
        } 
    }

    # Verify all mandatory params
    VerifyMandatoryParam -key $global:InstallationTargetPath
    VerifyMandatoryParam -key $global:ConjurServerDNS
    VerifyMandatoryParam -key $global:VaultName
    VerifyMandatoryParam -key $global:VaultAddress
    VerifyMandatoryParam -key $global:VaultPort
    VerifyMandatoryParam -key $global:SynchronizerVaultUsername
    VerifyMandatoryParam -key $global:ConjurCredentialsFilePath
    VerifyMandatoryParam -key $global:ConjurAccountKey
}

# ----------------- Create PS Credentials -----------------
function CreatePSCredentials($username, $password, $outputPath)
{
    WriteOutput -Message "Creating credentials file for $username" -newLine

    try 
    {
        $credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $username,$password
        $credentials | Export-Clixml -Path $outputPath
    }
    finally 
    {
        if ($credentials)
        {
            $credentials.Password.Dispose()
        }
    }
    
}

# ----------------- Copy logs to target installation folder -----------------
function CopyLogs()
{
    try 
    {
        WriteOutput -Message "Copying log file to target installation folder" -newLine
        $global:LogFolderPath = (GetValueFromConfig -key $global:InstallationTargetPath) + "\Logs"
    
        if (-not (Test-Path -Path $global:LogFolderPath))
        {
            New-Item -ItemType directory -Path $global:LogFolderPath | Out-Null
        }

        # Copy installation log file to target installation folder
        Copy-Item -Path $global:LogFilePath -Destination $global:LogFolderPath -Force -ErrorAction Stop

    }
    catch
    {
        $errMsg = $_.Exception.Message
        Write-Error "Failed to copy log file to target installation with error `"$errMsg`""

        Exit 1
    }  
    
}

# ----------------- Create event log ---------------------
function CreateEventLog()
{
    WriteOutput -Message "Creating the Synchronizer event log" -newLine
    $SourceExists = [System.Diagnostics.EventLog]::SourceExists("CyberArk Vault-Conjur Synchronizer")
    
    if (!$SourceExists)
    {
        New-EventLog -LogName "CyberArk Vault-Conjur Synchronizer" -Source "CyberArk Vault-Conjur Synchronizer"
        Limit-EventLog -LogName "CyberArk Vault-Conjur Synchronizer" -MaximumSize 50MB
    }
    else
    {
        WriteOutput -Message "Synchronizer event log already exists" -newLine
    }
}

# ----------------- Install Service ---------------------
function InstallService()
{
    WriteOutput -Message "Installing the Vault-Conjur Synchronizer Windows Service" -newLine
    $service = Get-Service -Name CyberArkVaultConjurSynchronizer -ErrorAction SilentlyContinue

    if (!$service)
    {
        $exePath = [System.IO.Path]::Combine((GetValueFromConfig -key $global:InstallationTargetPath), "VaultConjurSynchronizer.exe")
        & sc.exe @("create","CyberArkVaultConjurSynchronizer","start=auto","binPath=$exePath","displayname=CyberArk Vault-Conjur Synchronizer")
        if ($LASTEXITCODE -ne 0)
        {
            throw "Vault-Conjur Synchronizer Windows Service installation failed"
        }
        & sc.exe @("description","CyberArkVaultConjurSynchronizer","Synchronizes secrets, stored and managed in the CyberArk Vault, with Conjur.")
        & sc.exe @("failure","CyberArkVaultConjurSynchronizer","reset=86400","actions=restart/60000/restart/60000//")
    }
    else
    {
        WriteOutput -Message "The Vault-Conjur Synchronizer Windows Service already installed" -newLine
    }
}

################################################################################################
#  Main script
################################################################################################

try 
{	
    # Get location of script
    $global:ScriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
    # Initialize log location
    $global:LogFilePath = "$global:ScriptDir\Installation.log"

    WriteOutput -Message "Starting Vault-Conjur Synchronizer installation"

    # Enable unzipping and encoding
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    Add-Type -AssemblyName System.Web
    
    if ($silent)
    {
        WriteOutput -Message "Running silent installation"
        ReadSilentInstallationConfigFile "$global:ScriptDir\silent.ini"
    }

    SetValueInConfig -key $global:InstallationTargetPath -value (ReadHostWithDefaultValue -Message "Specify Vault-Conjur Synchronizer installation target path" -defaultValue "${env:ProgramFiles}\CyberArk\Synchronizer")

    $InstallationTargetPath = (GetValueFromConfig -key $global:InstallationTargetPath)
    if (-not (Test-Path -Path $InstallationTargetPath))
    {
        Copy-Item -Path "$global:ScriptDir\..\VaultConjurSynchronizer" -Destination $InstallationTargetPath -Recurse -Force -ErrorAction Stop
    }
    else
    {
        WriteOutput -Message "Directory $InstallationTargetPath already exists"
    }

    UpdateTargetInstallationFolderPermissions

    InitConjur

    if (-not $silent)
    {
        $credFilePath = "$InstallationTargetPath\Vault\VaultConjurSynchronizerUser.cred"
        $createCredFilePath = "$global:ScriptDir\CreateCredFile"
        $SynchronizerExePath = (GetValueFromConfig -key $global:InstallationTargetPath) + "\VaultConjurSynchronizer.exe"
        CreateCredFile -credfilePath $credFilePath -createcredfilePath $createCredFilePath -runningExePath $SynchronizerExePath
    }

    # Edit Vault.ini
    $vaultFilePath = "$InstallationTargetPath\Vault\Vault.ini"
    WriteOutput -Message "Updating file $vaultFilePath" -newLine

    SetValueInConfig -key $global:VaultName -value (ReadHost "Specify Vault Name")
    SetValueInConfig -key $global:VaultAddress -value (ReadHost "Specify Vault Address(s) (separated by commas without spaces)")
    SetValueInConfig -key $global:VaultPort -value (ReadHostWithDefaultValue -Message "Specify Vault port" -defaultValue "1858")

    $VaultName = (GetValueFromConfig -key $global:VaultName)
    UpdateVaultIni -filePath $vaultFilePath -vaultName $VaultName -VaultAddress (GetValueFromConfig -key $global:VaultAddress) -vaultPort (GetValueFromConfig -key $global:VaultPort)
    
    # Edit VaultConjurSynchronizer.exe.config
    $itemsToUpdate = "INTEGRATION_VAULT_NAME=$VaultName"

    UpdateConfigFile -filePath ((GetValueFromConfig($global:InstallationTargetPath)) + "\VaultConjurSynchronizer.exe.config") -Items $itemsToUpdate

    # Create the Synchronizer Conjur host and policy
    $ConjurHostName = "Sync_$env:computername"
    
    CreateConjurHostAndPolicy -conjurHostId $ConjurHostName -conjurHostCredFileOutputPath "$global:ScriptDir\synchronizerConjurHost.xml" -vaultName $VaultName
    
    CreateEventLog

    InstallService
    
    WriteOutput -Message "Vault-Conjur Synchronizer installation ended successfully" -newLine
    Exit 0
}
catch
{
    $errMsg = $_.Exception.Message
    Write-Error "Installation ended with error `"$errMsg`""

    # Redirect the Exception to log file
    "Installation ended with error `"$errMsg`"" | Add-Content $global:LogFilePath
    $_ | Out-File $global:LogFilePath -Append
    Exit 1
}
finally 
{
    CopyLogs
}
# SIG # Begin signature block
# MIIb+wYJKoZIhvcNAQcCoIIb7DCCG+gCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASa0R4OLEndU+s
# XCAiQqkEIIaOhiTvYL9RF4c9f0MLDKCCCtIwggVWMIIEPqADAgECAhAZGjLLdZyX
# uM+sEY3VEn9JMA0GCSqGSIb3DQEBCwUAMIHKMQswCQYDVQQGEwJVUzEXMBUGA1UE
# ChMOVmVyaVNpZ24sIEluYy4xHzAdBgNVBAsTFlZlcmlTaWduIFRydXN0IE5ldHdv
# cmsxOjA4BgNVBAsTMShjKSAyMDA2IFZlcmlTaWduLCBJbmMuIC0gRm9yIGF1dGhv
# cml6ZWQgdXNlIG9ubHkxRTBDBgNVBAMTPFZlcmlTaWduIENsYXNzIDMgUHVibGlj
# IFByaW1hcnkgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkgLSBHNTAeFw0xNDAzMDQw
# MDAwMDBaFw0yNDAzMDMyMzU5NTlaMIGRMQswCQYDVQQGEwJVUzEdMBsGA1UEChMU
# U3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5l
# dHdvcmsxQjBABgNVBAMTOVN5bWFudGVjIENsYXNzIDMgRXh0ZW5kZWQgVmFsaWRh
# dGlvbiBDb2RlIFNpZ25pbmcgQ0EgLSBHMjCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBANAYAu7too0IWGMPJtfdInuI9uTH7DsmGHjTx6QgU42DfKU/fqXI
# K0ffDfWm2cMdJZNgz3zc6gMsvnh/XEhtpwLZSfih6+uaYXyfwCbW3BXYuBB8ILpe
# 9Cj2qOqnXHzGnJCQNDy2Iqz+ugw6HtZehLZb8KOBcHiKjUZSe/zbSfMpExF0T40W
# s8LjoC3HAwSdzMNy4Q4M+wKO8SYXe26u+Lczi6ZhS0Xf8iVEx/ewmCM23Ch5Cuib
# coio2Oiue38KZEWl8FeSmncGRR7rn+hm83p9koFfAC0euPZWE1piDbdHoY9y74Ne
# guCUmOGspa2GN+Cn07qxPnrrRajxwUR94gMCAwEAAaOCAW0wggFpMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwLwYDVR0fBCgwJjAkoCKgIIYeaHR0cDovL3Muc3ltY2IuY29t
# L3BjYTMtZzUuY3JsMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMDMA4GA1UdDwEB/wQE
# AwIBBjAuBggrBgEFBQcBAQQiMCAwHgYIKwYBBQUHMAGGEmh0dHA6Ly9zLnN5bWNk
# LmNvbTBfBgNVHSAEWDBWMFQGBFUdIAAwTDAjBggrBgEFBQcCARYXaHR0cHM6Ly9k
# LnN5bWNiLmNvbS9jcHMwJQYIKwYBBQUHAgIwGRoXaHR0cHM6Ly9kLnN5bWNiLmNv
# bS9ycGEwKQYDVR0RBCIwIKQeMBwxGjAYBgNVBAMTEVN5bWFudGVjUEtJLTEtNjI5
# MB0GA1UdDgQWBBQWZt5KNONQpxGGA7FsqcaszVlumzAfBgNVHSMEGDAWgBR/02Wn
# wt3su/AwCfNDOfoCrzMxMzANBgkqhkiG9w0BAQsFAAOCAQEAP1sZ8/oT1XU4Klru
# n1qgTKkdxcyU7t4V/vUQbqQbpWSDVBhYxAsooYXDTnTl/4l8/tXtPLpxn1YCJo8W
# Koj+sKMnIs5L4jiOAKY6hl+d5T6o3mRJQXRBIf0HyIQX2h1lMILLJk851gQnpIGx
# S0nDI4t+AjIYJ7erC/MYcrak7mcGbzimWI3g8X5dpGDGqOVQX+DouuKPmVi2taCo
# dvGi8RyIQXJ+UpebCjaZjVD3Aes85/AiauU1jGM2ihqx2WdmX5ca76ggnfAvumzO
# 2ZSFAPFY8X3JfCK1B10CxuYLv6uTk/8nGI4zNn5XNPHDrwTBhPFWs+iHgzb40wox
# 3G4sbTCCBXQwggRcoAMCAQICED5ln3kg+MWv69MOsLIUcYIwDQYJKoZIhvcNAQEL
# BQAwgZExCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlv
# bjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazFCMEAGA1UEAxM5U3lt
# YW50ZWMgQ2xhc3MgMyBFeHRlbmRlZCBWYWxpZGF0aW9uIENvZGUgU2lnbmluZyBD
# QSAtIEcyMB4XDTE2MDUwMTAwMDAwMFoXDTE5MDUwMTIzNTk1OVowgcwxEzARBgsr
# BgEEAYI3PAIBAxMCSUwxHTAbBgNVBA8TFFByaXZhdGUgT3JnYW5pemF0aW9uMRIw
# EAYDVQQFEwk1MTIyOTE2NDIxCzAJBgNVBAYTAklMMQ8wDQYDVQQIDAZJc3JhZWwx
# FDASBgNVBAcMC1BldGFoIFRpa3ZhMR8wHQYDVQQKDBZDeWJlcmFyayBTb2Z0d2Fy
# ZSBMdGQuMQwwCgYDVQQLDANSJkQxHzAdBgNVBAMUFkN5YmVyYXJrIFNvZnR3YXJl
# IEx0ZC4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHB72SWspE6oni
# TExg3OzvsyHZ0ShsffE2op8pkN/mK5pnIV2Qfcr9er/q2NhHR6hXKO+cmJB3sJzF
# UMORF17OsI4zEjf3zOzGuh/9RnT+FYauPz3ovzQ0oxLgZGsPyTJa+yzybXio9JPG
# W6z2dfZo0KAvAMVODYswAWu7yFzF7+4XEzAXtNTs7R7xVQNo3xUtjniOjApeliZt
# fTq8J9f21FV+jdYv5kgcn+V13V1O+LSCc5qKcEh/wqZhFBiwQOfr1/8vh297buJW
# ggj6X3Jxw7tQh/Av2EGFZFpF64jzCfTrUJoRLA1/4Clc5MGwyIjwNxn9QVW1Vdj/
# XHIYJQBBAgMBAAGjggGJMIIBhTAnBgNVHREEIDAeoBwGCCsGAQUFBwgDoBAwDgwM
# SUwtNTEyMjkxNjQyMAkGA1UdEwQCMAAwDgYDVR0PAQH/BAQDAgeAMCsGA1UdHwQk
# MCIwIKAeoByGGmh0dHA6Ly9zdy5zeW1jYi5jb20vc3cuY3JsMGAGA1UdIARZMFcw
# VQYFZ4EMAQMwTDAjBggrBgEFBQcCARYXaHR0cHM6Ly9kLnN5bWNiLmNvbS9jcHMw
# JQYIKwYBBQUHAgIwGQwXaHR0cHM6Ly9kLnN5bWNiLmNvbS9ycGEwFgYDVR0lAQH/
# BAwwCgYIKwYBBQUHAwMwHwYDVR0jBBgwFoAUFmbeSjTjUKcRhgOxbKnGrM1Zbpsw
# HQYDVR0OBBYEFOelUevNjygg3rPCdBdAaSB5qLvCMFgGCCsGAQUFBwEBBEwwSjAf
# BggrBgEFBQcwAYYTaHR0cDovL3N3LnN5bWNkLmNvbTAnBggrBgEFBQcwAoYbaHR0
# cDovL3N3MS5zeW1jYi5jb20vc3cuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCzKtBJ
# m+skCC1DR3v7Q2bQprtJXUceZX/PK5CBW729S7DkTdyhAQyuhZmL2OGPg1ViHOl4
# j+ry9qbVlGKpO5gcV9nJ9QUE+1b2I5Ld8sqw8tlU4mdV6arrLAcvJAjkQwGPg3WP
# nx3aYDhwzoyB/LcQzd9K9a8G2knzZ8o3JnuYx4DBqJQu6BUhv315uAwxujNMc46m
# OlFQtsG7yaUhbkegZ1Z0WufQ+o7q3/MLZQ+1hUdNpzHlhMe6DWh6B9WNeJ2gVJpw
# B8RqNogmesMO1svAk4BgpTE4kRa4TMbSby2gT8/HljZbhO8VcV4akIetlMiVJaWP
# TOkL7NZzYXO3u3woMYIQfzCCEHsCAQEwgaYwgZExCzAJBgNVBAYTAlVTMR0wGwYD
# VQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1
# c3QgTmV0d29yazFCMEAGA1UEAxM5U3ltYW50ZWMgQ2xhc3MgMyBFeHRlbmRlZCBW
# YWxpZGF0aW9uIENvZGUgU2lnbmluZyBDQSAtIEcyAhA+ZZ95IPjFr+vTDrCyFHGC
# MA0GCWCGSAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkD
# MQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJ
# KoZIhvcNAQkEMSIEICuq7CMlROXQAHjgL7vdh6Ot7sYLo048hNbr2hYD7SfXMA0G
# CSqGSIb3DQEBAQUABIIBAHcQHLmMOux29AUibjl0//kmKmmDJ8egB3DVV31sRPvb
# PWHsuBVsuUHHIv7wl+wm8GTFVnI392AnMVRXXCu6smQaJHYECYwItT4ooOqTIxTX
# yeeN6PblOBw0XPUmOmi+/0cKudEmaJsQp6udpGtrq1ArArI1m1Wu6L+YT3KGNBGn
# dl80NicRfFLY5kYcLV/vZwEdTInNCC+N3Tju6WU7vHb3UlTYWP3FAL7XAlLHEqC5
# xDNLu7j6ZYtObIMDM4p4wGbkk10YhW+pdMkEqPIcefW5UUqmdBRrAi+a8wie1EGV
# AgBfwrFyA6ynb4hFWGWryNfVk5u4I2dEtV/NtG3AU2qhgg4rMIIOJwYKKwYBBAGC
# NwMDATGCDhcwgg4TBgkqhkiG9w0BBwKggg4EMIIOAAIBAzENMAsGCWCGSAFlAwQC
# ATCB/gYLKoZIhvcNAQkQAQSgge4EgeswgegCAQEGC2CGSAGG+EUBBxcDMCEwCQYF
# Kw4DAhoFAAQUz7xVisypMbJmxysbBGHLDJdLpbYCFAbXKC0pV/pRS3RF9J7ExITW
# sSmOGA8yMDE4MDkxODE4MDk0MVowAwIBHqCBhqSBgzCBgDELMAkGA1UEBhMCVVMx
# HTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRl
# YyBUcnVzdCBOZXR3b3JrMTEwLwYDVQQDEyhTeW1hbnRlYyBTSEEyNTYgVGltZVN0
# YW1waW5nIFNpZ25lciAtIEczoIIKizCCBTgwggQgoAMCAQICEHsFsdRJaFFE98mJ
# 0pwZnRIwDQYJKoZIhvcNAQELBQAwgb0xCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5W
# ZXJpU2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6
# MDgGA1UECxMxKGMpIDIwMDggVmVyaVNpZ24sIEluYy4gLSBGb3IgYXV0aG9yaXpl
# ZCB1c2Ugb25seTE4MDYGA1UEAxMvVmVyaVNpZ24gVW5pdmVyc2FsIFJvb3QgQ2Vy
# dGlmaWNhdGlvbiBBdXRob3JpdHkwHhcNMTYwMTEyMDAwMDAwWhcNMzEwMTExMjM1
# OTU5WjB3MQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRp
# b24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxKDAmBgNVBAMTH1N5
# bWFudGVjIFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQC7WZ1ZVU+djHJdGoGi61XzsAGtPHGsMo8Fa4aaJwAyl2pN
# yWQUSym7wtkpuS7sY7Phzz8LVpD4Yht+66YH4t5/Xm1AONSRBudBfHkcy8utG7/Y
# lZHz8O5s+K2WOS5/wSe4eDnFhKXt7a+Hjs6Nx23q0pi1Oh8eOZ3D9Jqo9IThxNF8
# ccYGKbQ/5IMNJsN7CD5N+Qq3M0n/yjvU9bKbS+GImRr1wOkzFNbfx4Dbke7+vJJX
# cnf0zajM/gn1kze+lYhqxdz0sUvUzugJkV+1hHk1inisGTKPI8EyQRtZDqk+scz5
# 1ivvt9jk1R1tETqS9pPJnONI7rtTDtQ2l4Z4xaE3AgMBAAGjggF3MIIBczAOBgNV
# HQ8BAf8EBAMCAQYwEgYDVR0TAQH/BAgwBgEB/wIBADBmBgNVHSAEXzBdMFsGC2CG
# SAGG+EUBBxcDMEwwIwYIKwYBBQUHAgEWF2h0dHBzOi8vZC5zeW1jYi5jb20vY3Bz
# MCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5zeW1jYi5jb20vcnBhMC4GCCsGAQUF
# BwEBBCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL3Muc3ltY2QuY29tMDYGA1UdHwQv
# MC0wK6ApoCeGJWh0dHA6Ly9zLnN5bWNiLmNvbS91bml2ZXJzYWwtcm9vdC5jcmww
# EwYDVR0lBAwwCgYIKwYBBQUHAwgwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRp
# bWVTdGFtcC0yMDQ4LTMwHQYDVR0OBBYEFK9j1sqjToVy4Ke8QfMpojh/gHViMB8G
# A1UdIwQYMBaAFLZ3+mlIR59TEtXC6gcydgfRlwcZMA0GCSqGSIb3DQEBCwUAA4IB
# AQB16rAt1TQZXDJF/g7h1E+meMFv1+rd3E/zociBiPenjxXmQCmt5l30otlWZIRx
# MCrdHmEXZiBWBpgZjV1x8viXvAn9HJFHyeLojQP7zJAv1gpsTjPs1rSTyEyQY0g5
# QCHE3dZuiZg8tZiX6KkGtwnJj1NXQZAv4R5NTtzKEHhsQm7wtsX4YVxS9U72a433
# Snq+8839A9fZ9gOoD+NT9wp17MZ1LqpmhQSZt/gGV+HGDvbor9rsmxgfqrnjOgC/
# zoqUywHbnsc4uw9Sq9HjlANgCk2g/idtFDL8P5dA4b+ZidvkORS92uTTw+orWrOV
# WFUEfcea7CMDjYUq0v+uqWGBMIIFSzCCBDOgAwIBAgIQe9Tlr7rMBz+hASMEIkFN
# EjANBgkqhkiG9w0BAQsFADB3MQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50
# ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsx
# KDAmBgNVBAMTH1N5bWFudGVjIFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwHhcNMTcx
# MjIzMDAwMDAwWhcNMjkwMzIyMjM1OTU5WjCBgDELMAkGA1UEBhMCVVMxHTAbBgNV
# BAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVz
# dCBOZXR3b3JrMTEwLwYDVQQDEyhTeW1hbnRlYyBTSEEyNTYgVGltZVN0YW1waW5n
# IFNpZ25lciAtIEczMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArw6K
# qvjcv2l7VBdxRwm9jTyB+HQVd2eQnP3eTgKeS3b25TY+ZdUkIG0w+d0dg+k/J0oz
# Tm0WiuSNQI0iqr6nCxvSB7Y8tRokKPgbclE9yAmIJgg6+fpDI3VHcAyzX1uPCB1y
# SFdlTa8CPED39N0yOJM/5Sym81kjy4DeE035EMmqChhsVWFX0fECLMS1q/JsI9Kf
# DQ8ZbK2FYmn9ToXBilIxq1vYyXRS41dsIr9Vf2/KBqs/SrcidmXs7DbylpWBJiz9
# u5iqATjTryVAmwlT8ClXhVhe6oVIQSGH5d600yaye0BTWHmOUjEGTZQDRcTOPAPs
# twDyOiLFtG/l77CKmwIDAQABo4IBxzCCAcMwDAYDVR0TAQH/BAIwADBmBgNVHSAE
# XzBdMFsGC2CGSAGG+EUBBxcDMEwwIwYIKwYBBQUHAgEWF2h0dHBzOi8vZC5zeW1j
# Yi5jb20vY3BzMCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5zeW1jYi5jb20vcnBh
# MEAGA1UdHwQ5MDcwNaAzoDGGL2h0dHA6Ly90cy1jcmwud3Muc3ltYW50ZWMuY29t
# L3NoYTI1Ni10c3MtY2EuY3JsMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMA4GA1Ud
# DwEB/wQEAwIHgDB3BggrBgEFBQcBAQRrMGkwKgYIKwYBBQUHMAGGHmh0dHA6Ly90
# cy1vY3NwLndzLnN5bWFudGVjLmNvbTA7BggrBgEFBQcwAoYvaHR0cDovL3RzLWFp
# YS53cy5zeW1hbnRlYy5jb20vc2hhMjU2LXRzcy1jYS5jZXIwKAYDVR0RBCEwH6Qd
# MBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0yMDQ4LTYwHQYDVR0OBBYEFKUTAamfhcwb
# bhYeXzsxqnk2AHsdMB8GA1UdIwQYMBaAFK9j1sqjToVy4Ke8QfMpojh/gHViMA0G
# CSqGSIb3DQEBCwUAA4IBAQBGnq/wuKJfoplIz6gnSyHNsrmmcnBjL+NVKXs5Rk7n
# fmUGWIu8V4qSDQjYELo2JPoKe/s702K/SpQV5oLbilRt/yj+Z89xP+YzCdmiWRD0
# Hkr+Zcze1GvjUil1AEorpczLm+ipTfe0F1mSQcO3P4bm9sB/RDxGXBda46Q71Wkm
# 1SF94YBnfmKst04uFZrlnCOvWxHqcalB+Q15OKmhDc+0sdo+mnrHIsV0zd9HCYbE
# /JElshuW6YUI6N3qdGBuYKVWeg3IRFjc5vlIFJ7lv94AvXexmBRyFCTfxxEsHwA/
# w0sUxmcczB4Go5BfXFSLPuMzW4IPxbeGAk5xn+lmRT92MYICWjCCAlYCAQEwgYsw
# dzELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8w
# HQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMSgwJgYDVQQDEx9TeW1hbnRl
# YyBTSEEyNTYgVGltZVN0YW1waW5nIENBAhB71OWvuswHP6EBIwQiQU0SMAsGCWCG
# SAFlAwQCAaCBpDAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcN
# AQkFMQ8XDTE4MDkxODE4MDk0MVowLwYJKoZIhvcNAQkEMSIEIAdWsVsNkiVOLltW
# lkPNg0bOxcRqljWQM4vLsq04hCzuMDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEIMR0
# znYAfQI5Tg2l5N58FMaA+eKCATz+9lPvXbcf32H4MAsGCSqGSIb3DQEBAQSCAQBz
# mfiLgRKMVaI8x3ZYrbaOyG5X4ZHHFZGtvlP6cU85rhAoBIC/UuJmcVidRVCn/DKQ
# meQ1DOZJhOnsKwRTbP7hnUW9FGlkgGoLjGtpdGgM59MpuPm+XYVFQ768xfPXTBnV
# wEzTm9n0SqJPLZfNYOOAmX01mViqoGigkU5QkFBVOLpkrLV+TzYrOXKsUomNi4gS
# i1eTSs6cTqMASFzijTnYz3ZVJ65BiKJl+yYQdMCnFDPyB1rMlL1DK+bOErb5wLed
# RSQY2yTxP/ds6FodO95CRhDZlSpfFuQfA5xtsfsUt7HWNAapMrdM1ixSih4b70Gp
# 6DG50G5FV1oeijeeMgIb
# SIG # End signature block
