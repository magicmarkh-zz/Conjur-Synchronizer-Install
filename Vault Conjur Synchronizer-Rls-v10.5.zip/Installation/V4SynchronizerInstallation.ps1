﻿#-----------------------------------------
# This script installs the Vault-Conjur Synchronizer
#------------------------------------------

#Requires -Version 4.0

# ----------------- Global Variables Start -----------------
param([switch] $silent)

$global:ConjurrcPath = $null
$global:RubyPath = $null
$global:ScriptDir = $null
$global:LogFilePath = $null
$global:LogFolderPath = $null

$global:Config=@{}
$global:InstallationTargetPath="InstallationTargetPath"
$global:ConjurServerDNS="ConjurServerDNS"
$global:VaultName="VaultName"
$global:VaultAddress="VaultAddress"
$global:VaultPort="VaultPort"
$global:SynchronizerVaultUsername="SynchronizerVaultUsername"
$global:ConjurCredentialsFilePath="ConjurCredentialsFilePath"

# Sets the value in the config
function SetValueInConfig($key, $value)
{
    if ($silent -and $global:Config.ContainsKey($key))
    {
        return
    }
    
    $global:Config.Add($key, $value)
}

# Returns the value from the config
function GetValueFromConfig($key)
{
    return $global:Config.Get_Item($key)
}

# ----------------- Global Variables End -----------------

# ----------------- Create Conjur Host -----------------
# Creates a policy file with a host for the Synchronizer and loads it to Conjur
function CreateConjurHost($conjurHostId, $conjurHostCredFileOutputPath)
{
    WriteOutput -Message "Creating Synchronizer Conjur host" -newLine

    $PoliciesFolderPath = (GetValueFromConfig -key $global:InstallationTargetPath) + "\ConjurPolicies"
    $policyFilePath = "$PoliciesFolderPath\VaultConjurSynchronizerHostPolicy.yml"

    $policyFileContent = @" 
---
- !host
  id: $conjurHostId
"@ 

    New-Item $policyFilePath -type file -Force -Value $policyFileContent | Out-Null

    if ($silent)
    {
        $credentials = Import-Clixml -Path (GetValueFromConfig -key $global:ConjurCredentialsFilePath)
        $conjurUser = $credentials.UserName

        # The password will be disposed in ConvertSecurePasswordToPlainText
        $conjurApiKey = ConvertSecurePasswordToPlainText -securePassword $credentials.Password
    }
    else
    {
        $conjurUser = ReadHostWithDefaultValue -Message "Specify the Conjur username" -defaultValue "admin"
        $conjurApiKey = GetPassword -userPromptMsg "Specify the Conjur API Key or password (will not be echoed)"
    }

    [Environment]::SetEnvironmentVariable("CONJUR_AUTHN_LOGIN", $conjurUser, "Process")
    [Environment]::SetEnvironmentVariable("CONJUR_AUTHN_API_KEY", $conjurApiKey, "Process")

    # Check if host already exists in Conjur
    $conjurCommand = "conjur"
    $output = & $conjurCommand @("host", "show", $conjurHostId, "2>&1")
    if ($output -like '*error*' -and -not $output -like '*not found*')
    {
        throw "Couldn't create Synchronizer Conjur host $conjurHostId. [$output]"
    }

    if ([regex]::match($output,"{[\n\s]*`"id`":\s`"$conjurHostId`"").Success)
    {
        Write-Warning -Message "Synchronizer Conjur host $conjurHostId already exists" | Tee-Object -Append $global:LogFilePath
        return
    }

    # Create host
    $output = & $conjurCommand @("policy", "load", $policyFilePath)
    $newHostRegex = [regex]::match($output,"{`".*:host:(.*)`":`"(.*)`"}")
    if (-not $newHostRegex.Success)
    {
        throw "Couldn't create Synchronizer Conjur host $conjurHostId"
    }

    $hostname = "host/" + $newHostRegex.Groups[1].Value
    $apiKey = ConvertTo-SecureString -String $newHostRegex.Groups[2].Value -AsPlainText -Force

    CreatePSCredentials -username $hostname -password $apiKey -outputPath $conjurHostCredFileOutputPath

    WriteOutput -Message "Wrote Synchronizer Conjur host credentials to $conjurHostCredFileOutputPath"
}

# ----------------- Install Conjur CLI -----------------
function InstallConjurCLI()
{
    WriteOutput "Installing Conjur CLI" -newLine

    Unzip -zipfile "$global:ScriptDir\Conjur CLI\Ruby24-x64.zip" -outpath "$global:ScriptDir\Conjur CLI\Ruby24-x64"

    try 
    {
        Set-Location -Path "$global:ScriptDir\Conjur CLI\Ruby24-x64\Ruby24-x64\lib\ruby\gems\2.4.0\cache"

        InstallConjurCLIGem

        InitConjur

        # Set CONJURRC env variable
        WriteOutput -Message "Setting environment variable CONJURRC to $global:ConjurrcPath" -newLine
        [Environment]::SetEnvironmentVariable("CONJURRC", $global:ConjurrcPath, "Machine")
        $env:CONJURRC = [System.Environment]::GetEnvironmentVariable("CONJURRC","Machine")

        InstallPolicyPlugin
    }
    finally 
    {
        Set-Location -Path $global:ScriptDir
    }
}

# ----------------- Install Ruby -----------------
function InstallRuby()
{
    WriteOutput -Message "Installing Ruby" -newLine

    $cmd = "ruby"
    $versionMajor = 2
    $versionMinor = 4
    $versionPatch = 1

    if (IsInstalled -cmdLet $cmd -versionRegex 'ruby (\d).(\d).(\d).*' -versionMajor $versionMajor -versionMinor $versionMinor -versionPatch $versionPatch)
    {
        $global:RubyPath = Get-Command ruby | Select-Object -ExpandProperty Definition
        $global:RubyPath = $global:RubyPath.Substring(0, $global:RubyPath.lastIndexOf('\bin\ruby.exe'))

        WriteOutput -Message "$cmd $versionMajor.$versionMinor.$versionPatch or up is already installed"
        return
    }
       
    $ruby_inst_process = Start-Process -FilePath "$global:ScriptDir\Conjur CLI\rubyinstaller-2.4.1-1-x64.exe" -ArgumentList "/verysilent /tasks=modpath,noridkinstall" -PassThru -Wait 
    if ($ruby_inst_process.ExitCode -ne 0) 
    {
        throw "Ruby installation failed"
    }

     # We refresh the Path env so we can use 'gem' that was added during Ruby installation
    RefreshPath

    $global:RubyPath = Get-Command ruby | Select-Object -ExpandProperty Definition
    $global:RubyPath = $global:RubyPath.Substring(0, $global:RubyPath.lastIndexOf('\bin\ruby.exe'))

    UpdateRubyInstallationFilePermissions
}

# ----------------- Install Conjur CLI Gem -----------------
# Installs the Conjur CLI ruby gem
function InstallConjurCLIGem()
{
    WriteOutput -Message "Installing Conjur CLI gem (this can take a while)" -newLine

    $cmd = "conjur"
    $versionMajor = 5
    $versionMinor = 6
    $versionPatch = 3

    if (IsInstalled -cmdLet $cmd -versionRegex 'conjur version (\d).(\d).(\d)' -versionMajor $versionMajor -versionMinor $versionMinor -versionPatch $versionPatch)
    {
        WriteOutput -Message "$cmd $versionMajor.$versionMinor.$versionPatch or up is already installed"
        return
    }

    $gemCommand = Get-Command "gem"
    & $gemCommand @("install", "conjur-cli", "-v", "$versionMajor.$versionMinor.$versionPatch", "-l")
}

# ----------------- Is Installed -----------------
# Checks a cmdLet is not installed with a given version
function IsInstalled($cmdLet, $versionRegex, $versionMajor, $versionMinor, $versionPatch)
{
    if (CmdletExist -cmd $cmdLet)
    {
        $command = Get-Command $cmdLet
        $output = & $command @("-v")

        $versionIntalled = [regex]::match($output,$versionRegex).Groups
        return (([int]$versionIntalled[1].Value -ge $versionMajor) -and ([int]$versionIntalled[2].Value -ge $versionMinor) -and ([int]$versionIntalled[3].Value -ge $versionPatch))
    }

    return $false;
}

# ----------------- Install Policy Plugin -----------------
# Installs the Cnjur policy plugin in order to load poplicies to Conjur
function InstallPolicyPlugin()
{
    WriteOutput -Message "Installing Conjur policy plugin (this can take a while)" -newLine

    $conjurCommand = Get-Command "conjur"
    & $conjurCommand @("plugin", "install", "policy")
}

# ----------------- Save Certificate -----------------
# Retrieve certificate from remote server and load it to root cert store
function Save-Certificate($serverUri, $certPath)
{
    $builder = New-Object System.Text.StringBuilder
    $request = [System.Net.WebRequest]::CreateHttp($serverUri)
    $request.ServerCertificateValidationCallback = 
    {
        param(
        [System.Object]$sender,
        [System.Security.Cryptography.X509Certificates.X509Certificate]$certificate,
        [System.Security.Cryptography.X509Certificates.X509Chain]$chain,
        [System.Net.Security.SslPolicyErrors]$sslPolicyErrors)

        $cert2 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $certificate

        if ($chain.Build($cert2))
        {
            return $true;
        }

        $issuer = $chain.ChainElements[$chain.ChainElements.Count - 1].Certificate

        $builder.AppendLine("-----BEGIN CERTIFICATE-----")
        $builder.AppendLine([System.Convert]::ToBase64String($issuer.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert), [System.Base64FormattingOptions]::InsertLineBreaks))
        $builder.AppendLine("-----END CERTIFICATE-----")
    
        return $true
    }

    $response = $request.GetResponse()

    if ($builder.Length -gt 0)
    {
        [System.IO.File]::WriteAllText($certPath, $builder.ToString())
        $responseCertLoad = Import-Certificate -CertStoreLocation "Cert:\LocalMachine\Root" -FilePath $certPath
        WriteOutput -Message "Server certificate was loaded into LocalMachie\Root store, $responseCertLoad" -newLine
        [System.IO.File]::Delete($certPath)
    }

}

# ----------------- Init Conjur -----------------
# Inits the Conjur CLI with the propmted hostname 
# and writes the conf & cert files to the default location
function InitConjur()
{
    WriteOutput -Message "Starting Conjur init" -newLine

    SetValueInConfig -key $global:ConjurServerDNS -value (ReadHost "Specify Conjur server hostname (and optional port in the format of hostname[:port])")
    $hostname = (GetValueFromConfig -key $global:ConjurServerDNS)
	$InstallationTargetPath = (GetValueFromConfig -key $global:InstallationTargetPath)
	Save-Certificate -serverUri "https://$hostname/info" -certPath "$InstallationTargetPath\conjur.pem"

    $conjurFilesFolder = (GetValueFromConfig -key $global:InstallationTargetPath) + "\Conjur CLI"
    if (-not (Test-Path -Path $conjurFilesFolder))
    {
        New-Item -ItemType directory -Path $conjurFilesFolder | Out-Null
    }
    
    RemoveFileIfExist -FileName "$conjurFilesFolder\conjur-*.pem"
    RemoveFileIfExist -FileName "$conjurFilesFolder\.conjurrc"

    $conjurCommand = Get-Command "conjur"
    
    # We pipe "yes" to trust Conjur certificate & the user should verify afterwards
    "yes" | & $conjurCommand @("init", "--hostname=$hostname", "--file=$conjurFilesFolder\.conjurrc", "2>NUL") | Tee-Object -Variable output

    $conjurrcRegex = [regex]::match($output,'Wrote configuration to (.*.conjurrc)')
    $conjurCertFileRegex = [regex]::match($output,'Wrote certificate to (.*.pem)')
    if (-not ($conjurrcRegex.Success -and $conjurCertFileRegex.Success))
    {
        throw "Conjur init failed"
    }

    $global:ConjurrcPath = $conjurrcRegex.Groups[1].Value
}

# ----------------- Create CredFile -----------------
function CreateCredFile($credFilePath, $createcredfilePath, $runningExePath) 
{
    WriteOutput -Message "Creating a credentials file for the Synchronizer Vault user" -newLine
    $SynchronizerVaultUsername = ReadHostWithDefaultValue -Message "Specify the Synchronizer Vault User's username" -defaultValue "Sync_$env:computername"
    $SynchronizerVaultUserPassword = GetPassword -userPromptMsg "Specify the Synchronizer Vault User's password (will not be echoed)"

    & "$createcredfilePath\CreateCredFile.exe" @("`"$credFilePath`"", "Password", "/Username", $SynchronizerVaultUsername, "/Password", $SynchronizerVaultUserPassword, "/ExePath", $runningExePath, "/Hostname")

    SetValueInConfig -key $global:SynchronizerVaultUsername -value $SynchronizerVaultUsername
}

# ----------------- Update Vault.ini -----------------
function UpdateVaultIni($filePath, $vaultName, $VaultAddress, $vaultPort)
{
    $fileContent = (Get-Content -path $filePath)

    $fileContent = $fileContent -replace "VAULT\s?=\s?`"?[\s\S]*`"?", "VAULT=`"$vaultName`""
    $fileContent = $fileContent -replace "ADDRESS\s?=\s?`"?[\s\S]*`"?", "ADDRESS=$VaultAddress"
    $fileContent = $fileContent -replace "PORT\s?=\s?`"?[\s\S]*`"?", "PORT=`"$vaultPort`""

    $fileContent | Set-Content $filePath
}

# ----------------- Update Config file -----------------
function UpdateConfigFile($filePath, $Items)
{
    WriteOutput -Message "Updating file $filePath" -newLine
    
    $parsedValues = @{}
    
    $Items = $Items -split ", "
    $Items | foreach {
        $item = $_.split("=")
        $parsedValues.Add($item[0], $item[1])
    }
        
    $xml = [xml](Get-Content $filePath)
    foreach ($elem in $xml.configuration.appSettings.ChildNodes)
    { 
        if ($elem.key)
        {
            if ($parsedValues.ContainsKey($elem.key))
            {
                WriteOutput -Message "Updating the value of $($elem.key) to $($parsedValues[$elem.key])"
                $elem.value = $parsedValues[$elem.key]
            }
        }
    }
    
    $xml.Save($filePath)
}

function UpdateRubyInstallationFilePermissions()
{
    ### set Ruby folder ACL ###

    WriteOutput -Message "Setting access permissions recursively to folder $global:RubyPath for Administrators Group" -newLine
    # retrieve ACL (Access Control List) of Installation target folder 
    $Acl = Get-Acl $global:RubyPath
    
    # protect the access rules associated with this ObjectSecurity object from inheritance (=True) & Don't preserve inherited access rules (=False)
    $Acl.SetAccessRuleProtection($True , $False) 
    
    # Grant “Full Control” permissions to Administrators only, propagating via inheritance to files and subfolders.
    $Ar = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators","FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
    $Acl.SetAccessRule($Ar)
    Set-Acl $global:RubyPath $Acl
}

function UpdateConjurPoliciesFolderPermissions()
{
    $InstallationTargetPath = (GetValueFromConfig -key $global:InstallationTargetPath)
    WriteOutput -Message "Setting read permission reacursively to folder ConjurPolicies for Users Group" -newLine

    # retrieve ACL (Access Control List) of Installation target folder 
    $Acl = Get-Acl $InstallationTargetPath\ConjurPolicies
    # protect the access rules associated with this ObjectSecurity object from inheritance (=True) & Don't preserve inherited access rules (=False)
    $Acl.SetAccessRuleProtection($False , $True) 
    $Ar = New-Object System.Security.AccessControl.FileSystemAccessRule("Users","Read", "ContainerInherit, ObjectInherit", "None","Allow")
    $Acl.SetAccessRule($Ar)
    Set-Acl $InstallationTargetPath\ConjurPolicies $Acl
}

function UpdateTargetInstallationFolderPermissions()
{
    $InstallationTargetPath = (GetValueFromConfig -key $global:InstallationTargetPath)
    WriteOutput -Message "Setting access permission recursively to folder $InstallationTargetPath for Administrators Group" -newLine
    
    ### set Synchronizer Installation folder ACL ###

    # retrieve ACL (Access Control List) of Installation target folder 
    $Acl = Get-Acl $InstallationTargetPath
    # protect the access rules associated with this ObjectSecurity object from inheritance (=True) & Don't preserve inherited access rules (=False)
    $Acl.SetAccessRuleProtection($True , $False)     
    # Grant “Full Control” permissions to Administrators 
    $Ar = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators","FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
    $Acl.SetAccessRule($Ar)
    # Grant "Read" permissions to Users
    $Ar = New-Object System.Security.AccessControl.FileSystemAccessRule("Users","Read", "None", "None","Allow")
    $Acl.SetAccessRule($Ar)
    Set-Acl $InstallationTargetPath $Acl
}

################################################################################################
#  Utils
################################################################################################

function ConvertSecurePasswordToPlainText($securePassword) 
{
    $BSTR = [System.IntPtr]::Zero
    try 
    {
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
        $plainTextPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
        return $plainTextPassword
    } 
    finally 
    {
        $securePassword.Dispose()
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
    }
}

# ----------------- Get Password -----------------
# Receive the password from the user in a secured manner and tranform it to plain text for login
function GetPassword($userPromptMsg) 
{
    $securePassword = ReadHost $userPromptMsg -AsSecureString

    # The password will be disposed in ConvertSecurePasswordToPlainText
    return ConvertSecurePasswordToPlainText -securePassword $securePassword
}

# ----------------- Unzip -----------------
# Unzip a specifed zip file to a specified location, if not exists in the output path
function Unzip($zipfile, $outpath)
{
    WriteOutput -Message "Unzipping $zipfile to $outpath"

    if(-not (Test-Path $outpath ))
    {
        [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $outpath)
    }
    else 
    {
        WriteOutput -Message "Directory $outpath already exists"
    }
}

# ----------------- Remove File If Exist -----------------
# Removes a file from a specified location, if it exists
function RemoveFileIfExist($FileName)
{
    if (Test-Path $FileName) 
    {
        WriteOutput -Message "Removing file $FileName" 
        Remove-Item $FileName
    }
}

function CmdletExist($cmd)
{
    return Get-Command $cmd -errorAction SilentlyContinue
}

# ----------------- Refresh Path -----------------
# Refreshes the Path environment variable
function RefreshPath()
{
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User") 
}


# ----------------- Write Output -----------------
# Wrapper for the PowerShell Write-Output
function WriteOutput($message, [switch]$newLine)
{
    if ($newLine) 
    {
        $message = "`r`n$message"
    }

    Write-Output $message | Tee-Object -Append $global:LogFilePath
}

# ----------------- Read Host -----------------
# Wrapper for the PowerShell Read-Host 
function ReadHost($message, [switch] $AsSecureString)
{
    if ($silent)
    {
        return
    }

    $message = "`r`n$message"

	# Write to log file
    $message | Out-File $global:LogFilePath -Append
    
    if ($AsSecureString) 
    {
        return (Read-Host "$message" -AsSecureString)
    }
    else
    {
        $input = Read-Host "$message"
        
        # Write to log file
        $input | Out-File $global:LogFilePath -Append
        
        return ($input)
    }
}

# Reads input from host with default value
function ReadHostWithDefaultValue($message, $defaultValue)
{
    $ret = ReadHost -Message "$message [$defaultValue]"
    if ($ret -eq '' -and $defaultValue -ne '') 
    {
        $ret = $defaultValue
    }

    # Write to log file
    $ret | Out-File $global:LogFilePath -Append
    return $ret
}

# ----------------- Read config file -----------------
function VerifyMandatoryParam($key)
{
    $value = GetValueFromConfig -key $key
    if ([string]::IsNullOrEmpty($value) -or [string]::IsNullOrWhiteSpace($value))
    {
        throw "Missing mandatory param [$key]"
    }
}

# ----------------- Read Silent Installation Config File -----------------
function ReadSilentInstallationConfigFile($path)
{
    $SingleQuoteRegex = '^"(.*)"$'
    $DoubleQuoteRegex = "^'(.*)'$"

    $fileContent = Get-Content $path
    foreach ($line in $fileContent) 
    {
        $values = [regex]::split($line,'=')
        if (($values[0].CompareTo("") -ne 0) -and (-not $values[0].StartsWith("[")) -and (-not $values[0].StartsWith("#"))) 
        { 
            SetValueInConfig -key $values[0] -value ($values[1] -replace $DoubleQuoteRegex,'$1' -replace $SingleQuoteRegex,'$1') 
        } 
    }

    # Verify all mandatory params
    VerifyMandatoryParam -key $global:InstallationTargetPath
    VerifyMandatoryParam -key $global:ConjurServerDNS
    VerifyMandatoryParam -key $global:VaultName
    VerifyMandatoryParam -key $global:VaultAddress
    VerifyMandatoryParam -key $global:VaultPort
    VerifyMandatoryParam -key $global:SynchronizerVaultUsername
    VerifyMandatoryParam -key $global:ConjurCredentialsFilePath
}

# ----------------- Create PS Credentials -----------------
function CreatePSCredentials($username, $password, $outputPath)
{
    WriteOutput -Message "Creating credentials file for $username" -newLine

    try 
    {
        $credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $username,$password
        $credentials | Export-Clixml -Path $outputPath
    }
    finally 
    {
        if ($credentials)
        {
            $credentials.Password.Dispose()
        }
    }
    
}

# ----------------- Copy logs to target installation folder -----------------
function CopyLogs()
{
    try 
    {
		WriteOutput -Message "Copying log file to target installation folder" -newLine
		$global:LogFolderPath = (GetValueFromConfig -key $global:InstallationTargetPath) + "\Logs"
    
		if (-not (Test-Path -Path $global:LogFolderPath))
		{
			New-Item -ItemType directory -Path $global:LogFolderPath | Out-Null
		}

		# Copy installation log file to target installation folder
		Copy-Item -Path $global:LogFilePath -Destination $global:LogFolderPath -Force -ErrorAction Stop

    }
    catch
    {
		$errMsg = $_.Exception.Message
		Write-Error "Failed to copy log file to target installation with error `"$errMsg`""

		Exit 1
    }  
    
}

# ----------------- Create event log ---------------------
function CreateEventLog()
{
    WriteOutput -Message "Creating the Synchronizer event log" -newLine
	$SourceExists = [System.Diagnostics.EventLog]::SourceExists("CyberArk Vault-Conjur Synchronizer")
	
	if (!$SourceExists)
	{
		New-EventLog -LogName "CyberArk Vault-Conjur Synchronizer" -Source "CyberArk Vault-Conjur Synchronizer"
		Limit-EventLog -LogName "CyberArk Vault-Conjur Synchronizer" -MaximumSize 50MB
	}
	else
	{
		WriteOutput -Message "Synchronizer event log already exists" -newLine
	}
}

# ----------------- Install Service ---------------------
function InstallService()
{
	WriteOutput -Message "Installing the Vault-Conjur Synchronizer Windows Service" -newLine
	$service = Get-Service -Name CyberArkVaultConjurSynchronizer -ErrorAction SilentlyContinue

	if (!$service)
	{
		$exePath = [System.IO.Path]::Combine((GetValueFromConfig -key $global:InstallationTargetPath), "VaultConjurSynchronizer.exe")
		& sc.exe @("create","CyberArkVaultConjurSynchronizer","start=auto","binPath=$exePath","displayname=CyberArk Vault-Conjur Synchronizer")
		if ($LASTEXITCODE -ne 0)
		{
			throw "Vault-Conjur Synchronizer Windows Service installation failed"
		}
		& sc.exe @("description","CyberArkVaultConjurSynchronizer","Synchronizes secrets, stored and managed in the CyberArk Vault, with Conjur.")
		& sc.exe @("failure","CyberArkVaultConjurSynchronizer","reset=86400","actions=restart/60000/restart/60000//")
	}
	else
	{
		WriteOutput -Message "The Vault-Conjur Synchronizer Windows Service already installed" -newLine
	}
}

################################################################################################
#  Main script
################################################################################################

try 
{
    # Get location of script
    $global:ScriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
    # Initialize log location
    $global:LogFilePath = "$global:ScriptDir\Installation.log"
    
    WriteOutput -Message "Starting Vault-Conjur Synchronizer installation"

    # Enable unzipping
    Add-Type -AssemblyName System.IO.Compression.FileSystem

    
    if ($silent)
    {
        WriteOutput -Message "Running silent installation"
        ReadSilentInstallationConfigFile "$global:ScriptDir\silent.ini"
    }

    SetValueInConfig -key $global:InstallationTargetPath -value (ReadHostWithDefaultValue -Message "Specify Vault-Conjur Synchronizer installation target path" -defaultValue "${env:ProgramFiles}\CyberArk\Synchronizer")

    $InstallationTargetPath = (GetValueFromConfig -key $global:InstallationTargetPath)
    if (-not (Test-Path -Path $InstallationTargetPath))
    {
        Copy-Item -Path "$global:ScriptDir\..\VaultConjurSynchronizer" -Destination $InstallationTargetPath -Recurse -Force -ErrorAction Stop
    }
    else
    {
        WriteOutput -Message "Directory $InstallationTargetPath already exists"
    }

    UpdateTargetInstallationFolderPermissions

    InstallRuby

    InstallConjurCLI

    if (-not $silent)
    {
        $credFilePath = "$InstallationTargetPath\Vault\VaultConjurSynchronizerUser.cred"
        $createCredFilePath = "$global:ScriptDir\CreateCredFile"
        $SynchronizerExePath = (GetValueFromConfig -key $global:InstallationTargetPath) + "\VaultConjurSynchronizer.exe"
        CreateCredFile -credfilePath $credFilePath -createcredfilePath $createCredFilePath -runningExePath $SynchronizerExePath
    }

    # Edit Vault.ini
    $vaultFilePath = "$InstallationTargetPath\Vault\Vault.ini"
    WriteOutput -Message "Updating file $vaultFilePath" -newLine

    SetValueInConfig -key $global:VaultName -value (ReadHost "Specify Vault Name")
    SetValueInConfig -key $global:VaultAddress -value (ReadHost "Specify Vault Address")
    SetValueInConfig -key $global:VaultPort -value (ReadHostWithDefaultValue -Message "Specify Vault port" -defaultValue "1858")

    $VaultName = (GetValueFromConfig -key $global:VaultName)
    UpdateVaultIni -filePath $vaultFilePath -vaultName $VaultName -VaultAddress (GetValueFromConfig -key $global:VaultAddress) -vaultPort (GetValueFromConfig -key $global:VaultPort)
    
    $itemsToUpdate = "INTEGRATION_VAULT_NAME=$VaultName"

    if ($global:RubyPath -ne $null) 
    {
        $itemsToUpdate = "$itemsToUpdate, RUBY_PATH=$global:RubyPath\bin"
    }

    UpdateConfigFile -filePath ((GetValueFromConfig($global:InstallationTargetPath)) + "\VaultConjurSynchronizer.exe.config") -Items $itemsToUpdate

    # Create the Synchronizer Conjur host
    $ConjurHostName = "Sync_$env:computername"
	
    CreateConjurHost -conjurHostId $ConjurHostName -conjurHostCredFileOutputPath "$global:ScriptDir\synchronizerConjurHost.xml"

    UpdateConjurPoliciesFolderPermissions
	
	CreateEventLog

	InstallService

    WriteOutput -Message "Vault-Conjur Synchronizer installation ended successfully" -newLine
    Exit 0
}
catch
{
    $errMsg = $_.Exception.Message
    Write-Error "Installation ended with error `"$errMsg`""

    # Redirect the Exception to log file
    "Installation ended with error `"$errMsg`"" | Add-Content $global:LogFilePath
    $_ | Out-File $global:LogFilePath -Append
    Exit 1
}
finally 
{
    CopyLogs
}




# SIG # Begin signature block
# MIIb+wYJKoZIhvcNAQcCoIIb7DCCG+gCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCFQaXL/M1Y8x/0
# Y7GcZdX8CmbMWDHQNxNL7wOJmqOtjqCCCtIwggVWMIIEPqADAgECAhAZGjLLdZyX
# uM+sEY3VEn9JMA0GCSqGSIb3DQEBCwUAMIHKMQswCQYDVQQGEwJVUzEXMBUGA1UE
# ChMOVmVyaVNpZ24sIEluYy4xHzAdBgNVBAsTFlZlcmlTaWduIFRydXN0IE5ldHdv
# cmsxOjA4BgNVBAsTMShjKSAyMDA2IFZlcmlTaWduLCBJbmMuIC0gRm9yIGF1dGhv
# cml6ZWQgdXNlIG9ubHkxRTBDBgNVBAMTPFZlcmlTaWduIENsYXNzIDMgUHVibGlj
# IFByaW1hcnkgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkgLSBHNTAeFw0xNDAzMDQw
# MDAwMDBaFw0yNDAzMDMyMzU5NTlaMIGRMQswCQYDVQQGEwJVUzEdMBsGA1UEChMU
# U3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5l
# dHdvcmsxQjBABgNVBAMTOVN5bWFudGVjIENsYXNzIDMgRXh0ZW5kZWQgVmFsaWRh
# dGlvbiBDb2RlIFNpZ25pbmcgQ0EgLSBHMjCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBANAYAu7too0IWGMPJtfdInuI9uTH7DsmGHjTx6QgU42DfKU/fqXI
# K0ffDfWm2cMdJZNgz3zc6gMsvnh/XEhtpwLZSfih6+uaYXyfwCbW3BXYuBB8ILpe
# 9Cj2qOqnXHzGnJCQNDy2Iqz+ugw6HtZehLZb8KOBcHiKjUZSe/zbSfMpExF0T40W
# s8LjoC3HAwSdzMNy4Q4M+wKO8SYXe26u+Lczi6ZhS0Xf8iVEx/ewmCM23Ch5Cuib
# coio2Oiue38KZEWl8FeSmncGRR7rn+hm83p9koFfAC0euPZWE1piDbdHoY9y74Ne
# guCUmOGspa2GN+Cn07qxPnrrRajxwUR94gMCAwEAAaOCAW0wggFpMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwLwYDVR0fBCgwJjAkoCKgIIYeaHR0cDovL3Muc3ltY2IuY29t
# L3BjYTMtZzUuY3JsMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMDMA4GA1UdDwEB/wQE
# AwIBBjAuBggrBgEFBQcBAQQiMCAwHgYIKwYBBQUHMAGGEmh0dHA6Ly9zLnN5bWNk
# LmNvbTBfBgNVHSAEWDBWMFQGBFUdIAAwTDAjBggrBgEFBQcCARYXaHR0cHM6Ly9k
# LnN5bWNiLmNvbS9jcHMwJQYIKwYBBQUHAgIwGRoXaHR0cHM6Ly9kLnN5bWNiLmNv
# bS9ycGEwKQYDVR0RBCIwIKQeMBwxGjAYBgNVBAMTEVN5bWFudGVjUEtJLTEtNjI5
# MB0GA1UdDgQWBBQWZt5KNONQpxGGA7FsqcaszVlumzAfBgNVHSMEGDAWgBR/02Wn
# wt3su/AwCfNDOfoCrzMxMzANBgkqhkiG9w0BAQsFAAOCAQEAP1sZ8/oT1XU4Klru
# n1qgTKkdxcyU7t4V/vUQbqQbpWSDVBhYxAsooYXDTnTl/4l8/tXtPLpxn1YCJo8W
# Koj+sKMnIs5L4jiOAKY6hl+d5T6o3mRJQXRBIf0HyIQX2h1lMILLJk851gQnpIGx
# S0nDI4t+AjIYJ7erC/MYcrak7mcGbzimWI3g8X5dpGDGqOVQX+DouuKPmVi2taCo
# dvGi8RyIQXJ+UpebCjaZjVD3Aes85/AiauU1jGM2ihqx2WdmX5ca76ggnfAvumzO
# 2ZSFAPFY8X3JfCK1B10CxuYLv6uTk/8nGI4zNn5XNPHDrwTBhPFWs+iHgzb40wox
# 3G4sbTCCBXQwggRcoAMCAQICED5ln3kg+MWv69MOsLIUcYIwDQYJKoZIhvcNAQEL
# BQAwgZExCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlv
# bjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazFCMEAGA1UEAxM5U3lt
# YW50ZWMgQ2xhc3MgMyBFeHRlbmRlZCBWYWxpZGF0aW9uIENvZGUgU2lnbmluZyBD
# QSAtIEcyMB4XDTE2MDUwMTAwMDAwMFoXDTE5MDUwMTIzNTk1OVowgcwxEzARBgsr
# BgEEAYI3PAIBAxMCSUwxHTAbBgNVBA8TFFByaXZhdGUgT3JnYW5pemF0aW9uMRIw
# EAYDVQQFEwk1MTIyOTE2NDIxCzAJBgNVBAYTAklMMQ8wDQYDVQQIDAZJc3JhZWwx
# FDASBgNVBAcMC1BldGFoIFRpa3ZhMR8wHQYDVQQKDBZDeWJlcmFyayBTb2Z0d2Fy
# ZSBMdGQuMQwwCgYDVQQLDANSJkQxHzAdBgNVBAMUFkN5YmVyYXJrIFNvZnR3YXJl
# IEx0ZC4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHB72SWspE6oni
# TExg3OzvsyHZ0ShsffE2op8pkN/mK5pnIV2Qfcr9er/q2NhHR6hXKO+cmJB3sJzF
# UMORF17OsI4zEjf3zOzGuh/9RnT+FYauPz3ovzQ0oxLgZGsPyTJa+yzybXio9JPG
# W6z2dfZo0KAvAMVODYswAWu7yFzF7+4XEzAXtNTs7R7xVQNo3xUtjniOjApeliZt
# fTq8J9f21FV+jdYv5kgcn+V13V1O+LSCc5qKcEh/wqZhFBiwQOfr1/8vh297buJW
# ggj6X3Jxw7tQh/Av2EGFZFpF64jzCfTrUJoRLA1/4Clc5MGwyIjwNxn9QVW1Vdj/
# XHIYJQBBAgMBAAGjggGJMIIBhTAnBgNVHREEIDAeoBwGCCsGAQUFBwgDoBAwDgwM
# SUwtNTEyMjkxNjQyMAkGA1UdEwQCMAAwDgYDVR0PAQH/BAQDAgeAMCsGA1UdHwQk
# MCIwIKAeoByGGmh0dHA6Ly9zdy5zeW1jYi5jb20vc3cuY3JsMGAGA1UdIARZMFcw
# VQYFZ4EMAQMwTDAjBggrBgEFBQcCARYXaHR0cHM6Ly9kLnN5bWNiLmNvbS9jcHMw
# JQYIKwYBBQUHAgIwGQwXaHR0cHM6Ly9kLnN5bWNiLmNvbS9ycGEwFgYDVR0lAQH/
# BAwwCgYIKwYBBQUHAwMwHwYDVR0jBBgwFoAUFmbeSjTjUKcRhgOxbKnGrM1Zbpsw
# HQYDVR0OBBYEFOelUevNjygg3rPCdBdAaSB5qLvCMFgGCCsGAQUFBwEBBEwwSjAf
# BggrBgEFBQcwAYYTaHR0cDovL3N3LnN5bWNkLmNvbTAnBggrBgEFBQcwAoYbaHR0
# cDovL3N3MS5zeW1jYi5jb20vc3cuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCzKtBJ
# m+skCC1DR3v7Q2bQprtJXUceZX/PK5CBW729S7DkTdyhAQyuhZmL2OGPg1ViHOl4
# j+ry9qbVlGKpO5gcV9nJ9QUE+1b2I5Ld8sqw8tlU4mdV6arrLAcvJAjkQwGPg3WP
# nx3aYDhwzoyB/LcQzd9K9a8G2knzZ8o3JnuYx4DBqJQu6BUhv315uAwxujNMc46m
# OlFQtsG7yaUhbkegZ1Z0WufQ+o7q3/MLZQ+1hUdNpzHlhMe6DWh6B9WNeJ2gVJpw
# B8RqNogmesMO1svAk4BgpTE4kRa4TMbSby2gT8/HljZbhO8VcV4akIetlMiVJaWP
# TOkL7NZzYXO3u3woMYIQfzCCEHsCAQEwgaYwgZExCzAJBgNVBAYTAlVTMR0wGwYD
# VQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1
# c3QgTmV0d29yazFCMEAGA1UEAxM5U3ltYW50ZWMgQ2xhc3MgMyBFeHRlbmRlZCBW
# YWxpZGF0aW9uIENvZGUgU2lnbmluZyBDQSAtIEcyAhA+ZZ95IPjFr+vTDrCyFHGC
# MA0GCWCGSAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkD
# MQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJ
# KoZIhvcNAQkEMSIEILIQznXdgCUFOuvMlD7oLEZOf0alaFUj1mJg11CdI+OgMA0G
# CSqGSIb3DQEBAQUABIIBAKyXDwKjVOrrzph4Q9nR+BtW3HAhA+OpRpNbgWVFZgyf
# ifQWJp4QoB2p97IdcFMMS50mzUQhiZ8UVveeDboMBDDMJfhxVD8cNd1jCDwgIwyI
# uu3cExo8ber5RIYqEa7S7LpydbCpvtmwZmRcjGFzzI/6lH30J7DFqggU0paO+Wn+
# nsQ0Ri07eKGMEDTLZXzrosrxhQWF75qoON01LJvnBhwl904RxYwJEFOEFeo9E34H
# Ykh7WH/r/LM2GFL6eqbscnxYri1U1A9wdtyvUtiR78OkEW0KhA58UGKl1/3EoXi8
# bCGdgSNUy3pMPn9rEuzDjh1issQfaQGbYAZmIV3CnPehgg4rMIIOJwYKKwYBBAGC
# NwMDATGCDhcwgg4TBgkqhkiG9w0BBwKggg4EMIIOAAIBAzENMAsGCWCGSAFlAwQC
# ATCB/gYLKoZIhvcNAQkQAQSgge4EgeswgegCAQEGC2CGSAGG+EUBBxcDMCEwCQYF
# Kw4DAhoFAAQUOUCeC2qJIga6QMnKDu1ivDSrhNwCFAWegFeOCAfjLRJ3G27AQLTS
# +dsfGA8yMDE4MDkxODE4MDk0MFowAwIBHqCBhqSBgzCBgDELMAkGA1UEBhMCVVMx
# HTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRl
# YyBUcnVzdCBOZXR3b3JrMTEwLwYDVQQDEyhTeW1hbnRlYyBTSEEyNTYgVGltZVN0
# YW1waW5nIFNpZ25lciAtIEczoIIKizCCBTgwggQgoAMCAQICEHsFsdRJaFFE98mJ
# 0pwZnRIwDQYJKoZIhvcNAQELBQAwgb0xCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5W
# ZXJpU2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6
# MDgGA1UECxMxKGMpIDIwMDggVmVyaVNpZ24sIEluYy4gLSBGb3IgYXV0aG9yaXpl
# ZCB1c2Ugb25seTE4MDYGA1UEAxMvVmVyaVNpZ24gVW5pdmVyc2FsIFJvb3QgQ2Vy
# dGlmaWNhdGlvbiBBdXRob3JpdHkwHhcNMTYwMTEyMDAwMDAwWhcNMzEwMTExMjM1
# OTU5WjB3MQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRp
# b24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxKDAmBgNVBAMTH1N5
# bWFudGVjIFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQC7WZ1ZVU+djHJdGoGi61XzsAGtPHGsMo8Fa4aaJwAyl2pN
# yWQUSym7wtkpuS7sY7Phzz8LVpD4Yht+66YH4t5/Xm1AONSRBudBfHkcy8utG7/Y
# lZHz8O5s+K2WOS5/wSe4eDnFhKXt7a+Hjs6Nx23q0pi1Oh8eOZ3D9Jqo9IThxNF8
# ccYGKbQ/5IMNJsN7CD5N+Qq3M0n/yjvU9bKbS+GImRr1wOkzFNbfx4Dbke7+vJJX
# cnf0zajM/gn1kze+lYhqxdz0sUvUzugJkV+1hHk1inisGTKPI8EyQRtZDqk+scz5
# 1ivvt9jk1R1tETqS9pPJnONI7rtTDtQ2l4Z4xaE3AgMBAAGjggF3MIIBczAOBgNV
# HQ8BAf8EBAMCAQYwEgYDVR0TAQH/BAgwBgEB/wIBADBmBgNVHSAEXzBdMFsGC2CG
# SAGG+EUBBxcDMEwwIwYIKwYBBQUHAgEWF2h0dHBzOi8vZC5zeW1jYi5jb20vY3Bz
# MCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5zeW1jYi5jb20vcnBhMC4GCCsGAQUF
# BwEBBCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL3Muc3ltY2QuY29tMDYGA1UdHwQv
# MC0wK6ApoCeGJWh0dHA6Ly9zLnN5bWNiLmNvbS91bml2ZXJzYWwtcm9vdC5jcmww
# EwYDVR0lBAwwCgYIKwYBBQUHAwgwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRp
# bWVTdGFtcC0yMDQ4LTMwHQYDVR0OBBYEFK9j1sqjToVy4Ke8QfMpojh/gHViMB8G
# A1UdIwQYMBaAFLZ3+mlIR59TEtXC6gcydgfRlwcZMA0GCSqGSIb3DQEBCwUAA4IB
# AQB16rAt1TQZXDJF/g7h1E+meMFv1+rd3E/zociBiPenjxXmQCmt5l30otlWZIRx
# MCrdHmEXZiBWBpgZjV1x8viXvAn9HJFHyeLojQP7zJAv1gpsTjPs1rSTyEyQY0g5
# QCHE3dZuiZg8tZiX6KkGtwnJj1NXQZAv4R5NTtzKEHhsQm7wtsX4YVxS9U72a433
# Snq+8839A9fZ9gOoD+NT9wp17MZ1LqpmhQSZt/gGV+HGDvbor9rsmxgfqrnjOgC/
# zoqUywHbnsc4uw9Sq9HjlANgCk2g/idtFDL8P5dA4b+ZidvkORS92uTTw+orWrOV
# WFUEfcea7CMDjYUq0v+uqWGBMIIFSzCCBDOgAwIBAgIQe9Tlr7rMBz+hASMEIkFN
# EjANBgkqhkiG9w0BAQsFADB3MQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50
# ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsx
# KDAmBgNVBAMTH1N5bWFudGVjIFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwHhcNMTcx
# MjIzMDAwMDAwWhcNMjkwMzIyMjM1OTU5WjCBgDELMAkGA1UEBhMCVVMxHTAbBgNV
# BAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBUcnVz
# dCBOZXR3b3JrMTEwLwYDVQQDEyhTeW1hbnRlYyBTSEEyNTYgVGltZVN0YW1waW5n
# IFNpZ25lciAtIEczMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArw6K
# qvjcv2l7VBdxRwm9jTyB+HQVd2eQnP3eTgKeS3b25TY+ZdUkIG0w+d0dg+k/J0oz
# Tm0WiuSNQI0iqr6nCxvSB7Y8tRokKPgbclE9yAmIJgg6+fpDI3VHcAyzX1uPCB1y
# SFdlTa8CPED39N0yOJM/5Sym81kjy4DeE035EMmqChhsVWFX0fECLMS1q/JsI9Kf
# DQ8ZbK2FYmn9ToXBilIxq1vYyXRS41dsIr9Vf2/KBqs/SrcidmXs7DbylpWBJiz9
# u5iqATjTryVAmwlT8ClXhVhe6oVIQSGH5d600yaye0BTWHmOUjEGTZQDRcTOPAPs
# twDyOiLFtG/l77CKmwIDAQABo4IBxzCCAcMwDAYDVR0TAQH/BAIwADBmBgNVHSAE
# XzBdMFsGC2CGSAGG+EUBBxcDMEwwIwYIKwYBBQUHAgEWF2h0dHBzOi8vZC5zeW1j
# Yi5jb20vY3BzMCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5zeW1jYi5jb20vcnBh
# MEAGA1UdHwQ5MDcwNaAzoDGGL2h0dHA6Ly90cy1jcmwud3Muc3ltYW50ZWMuY29t
# L3NoYTI1Ni10c3MtY2EuY3JsMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMA4GA1Ud
# DwEB/wQEAwIHgDB3BggrBgEFBQcBAQRrMGkwKgYIKwYBBQUHMAGGHmh0dHA6Ly90
# cy1vY3NwLndzLnN5bWFudGVjLmNvbTA7BggrBgEFBQcwAoYvaHR0cDovL3RzLWFp
# YS53cy5zeW1hbnRlYy5jb20vc2hhMjU2LXRzcy1jYS5jZXIwKAYDVR0RBCEwH6Qd
# MBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0yMDQ4LTYwHQYDVR0OBBYEFKUTAamfhcwb
# bhYeXzsxqnk2AHsdMB8GA1UdIwQYMBaAFK9j1sqjToVy4Ke8QfMpojh/gHViMA0G
# CSqGSIb3DQEBCwUAA4IBAQBGnq/wuKJfoplIz6gnSyHNsrmmcnBjL+NVKXs5Rk7n
# fmUGWIu8V4qSDQjYELo2JPoKe/s702K/SpQV5oLbilRt/yj+Z89xP+YzCdmiWRD0
# Hkr+Zcze1GvjUil1AEorpczLm+ipTfe0F1mSQcO3P4bm9sB/RDxGXBda46Q71Wkm
# 1SF94YBnfmKst04uFZrlnCOvWxHqcalB+Q15OKmhDc+0sdo+mnrHIsV0zd9HCYbE
# /JElshuW6YUI6N3qdGBuYKVWeg3IRFjc5vlIFJ7lv94AvXexmBRyFCTfxxEsHwA/
# w0sUxmcczB4Go5BfXFSLPuMzW4IPxbeGAk5xn+lmRT92MYICWjCCAlYCAQEwgYsw
# dzELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8w
# HQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMSgwJgYDVQQDEx9TeW1hbnRl
# YyBTSEEyNTYgVGltZVN0YW1waW5nIENBAhB71OWvuswHP6EBIwQiQU0SMAsGCWCG
# SAFlAwQCAaCBpDAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcN
# AQkFMQ8XDTE4MDkxODE4MDk0MFowLwYJKoZIhvcNAQkEMSIEIFmaY4ric2wPAYAi
# imq97FGgqUWkQWULBJJK8kNeXSofMDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEIMR0
# znYAfQI5Tg2l5N58FMaA+eKCATz+9lPvXbcf32H4MAsGCSqGSIb3DQEBAQSCAQCX
# mujDvtD6Annjtcd59mg9YYLmBzXzbPgb69ectVK09/5Y5vQznSNWeEbmsZsC+9iv
# KtNN0D+5PODIpCEYtEeVKl3dZGFxfdQ3nYLjr/HdvXAvGouF+WfFN0tBsYON1OgP
# mDQGowteVXU3Re8IF1sJ4Z+q4cbKrVd9y4Nu+vnJNc1dgjg5GXYKUzCw/v+j4Ipy
# SQnv++HU3TnSPZAyDgkJMoVRCd+NjTEsaGg+wzjOl9qouhxa7yb6JVqsyRWrINTu
# /Ng1/b9Ao7Jv67x8HAuwvmegN7dUOCHfg4jzwL8y/nFHCYVKmPS38rbtrNqfZCr2
# tKcpyGgOeHiS/Xe0tVop
# SIG # End signature block
